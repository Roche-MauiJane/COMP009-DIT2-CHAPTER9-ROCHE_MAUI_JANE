module COMP009 {
	requires java.desktop;
}

